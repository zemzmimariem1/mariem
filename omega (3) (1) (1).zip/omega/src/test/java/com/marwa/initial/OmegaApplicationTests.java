package com.marwa.initial;



import java.util.Date;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.marwa.initial.entity.Panier;
import com.marwa.initial.entity.Produit;
import com.marwa.initial.entity.Role;
import com.marwa.initial.entity.User;
import com.marwa.initial.entity.ligne_panier_commande;
import com.marwa.initial.repostry.Repostrypanier;
import com.marwa.initial.repostry.Repostryproduit;
import com.marwa.initial.repostry.Repostryuser;
import com.marwa.initial.repostry.repostrylignecommande;
import com.marwa.initial.service.userservice;
@SpringBootTest
class OmegaApplicationTests {
	@Autowired
	private Repostryproduit produitRepository;
	@Autowired
	private Repostryuser userrepostry;
	@Autowired
	repostrylignecommande lpancomRepository;
	@Autowired
	Repostrypanier panRepository;
	@Autowired
	userservice user;
	@Test
	public void testCreateProduit() {
	Produit prod = new Produit(null, "photo.png", "huile",null, 5.500,null ,null, null, null);
	produitRepository.save(prod);
	}
	@Test
	public void testauthentification() {
		userrepostry.findByemail("marwaselmi@omega.tn");
	}
	@Test
	public void testajoutarticleaupanier() {
		Produit prod = new Produit(null, "photo.png", "huile",null, 5.500,null ,null, null, null);
		produitRepository.save(prod);
		ligne_panier_commande ligne = new ligne_panier_commande(null, 3, prod);
		lpancomRepository.save(ligne);
	}
	@Test
	public void testinscription() {
		Panier p =  new Panier();
		panRepository.save(p);
		
		User client = new User(null,"mariemzemzmi@omega.tn","123456", "zemzmi", "marwa", "tborba",
				null,null);
		client.setPanier(p);
		userrepostry.save(client);
	}

	@Test
	public void testdeletprofil() {
				User client = new User(null,"mariemzemzmi@omega.tn","123456", "zemzmi", "marwa", "tborba",
				null,null);
		userrepostry.save(client);
		user.deleteUser(client);
		
	}
	
	@Test
	void contextLoads() {
	}

}
