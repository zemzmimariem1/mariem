package com.marwa.initial.repostry;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;


import com.marwa.initial.entity.ligne_panier_commande;

public interface repostrylignecommande extends JpaRepository <ligne_panier_commande, Long> {
	List<ligne_panier_commande> findByLpanierIdpanier(Long id);
}
