package com.marwa.initial.restcontrollers;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.marwa.initial.entity.Reclamation;
import com.marwa.initial.entity.User;
import com.marwa.initial.entity.statistiquesatisfactiondeclient;
import com.marwa.initial.repostry.reclamationrepostry;
import com.marwa.initial.repostry.reposotorystaticsatisfaction;
import com.marwa.initial.service.Reclamationservice;

@RestController
@RequestMapping("/aprec")
@CrossOrigin
public class reclamationcontroller {
	@Autowired
	Reclamationservice recserv;
	@Autowired 
	reclamationrepostry recrep;
	@Autowired
	reposotorystaticsatisfaction stat;
	/*afficher tout les reclamation*/
	@RequestMapping(method = RequestMethod.GET)
	public List<Reclamation> getAllProduits() {
	return recserv.getAllreclamation();
	}
	/*reponder au reclamation*/
	@RequestMapping(method = RequestMethod.PUT)
	public Reclamation updatereclamation(@RequestBody Reclamation reclamation) {
		return recserv.updaterec(reclamation);
	}
	/*ajouter reclamation*/
	@RequestMapping(method = RequestMethod.POST)
	public Reclamation createreclamation(@RequestBody Reclamation reclamation) {
		List<statistiquesatisfactiondeclient> s = stat.findAll();
		if (s.size()==0) {
			statistiquesatisfactiondeclient x =new statistiquesatisfactiondeclient();
		x.setAns(new Date().getYear());
		x.setMois(new Date().getMonth());
		x.setNbdereclamation(1);
		stat.save(x);
		
	 }else {
		 for(int i = 0; i<s.size();i++) {
			 if(s.get(i).getMois()== new Date().getMonth()) {
				int y= s.get(i).getNbdereclamation()+1;
				s.get(i).setNbdereclamation(y);
			 }
			 
		 }
	 }
		return recserv.saverec(reclamation);
	}
	/*afficherreclamation par son idcommande*/
	@RequestMapping(value ="/{id}",method = RequestMethod.GET)
	public Reclamation getreclamationByIdrec(@PathVariable("id") Long id) {
	return recrep.findByCmdIdcommande(id);
	 }
}
