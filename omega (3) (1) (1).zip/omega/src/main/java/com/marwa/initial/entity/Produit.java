package com.marwa.initial.entity;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;



@Entity
public class Produit {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long idProduit;
	private String image ;
	private String referance;
	private String nomProduit;
	private Double prixProduit;
	private Date dateCreation;
	@ManyToOne
	private Categorie categorie;
	@OneToMany(mappedBy = "id_produit",cascade=CascadeType.ALL)
	@JsonIgnore
	    private List<ligne_panier_commande> ligne_panier;
		@OneToMany(mappedBy = "produit",cascade=CascadeType.ALL)
		@JsonIgnore
		    private List<statistiquedebesoin> statbesoin;
	public Produit() {
		super();
		}
	public Produit(Long idProduit, String image, String referance, String nomProduit, Double prixProduit,
			Date dateCreation, Categorie categorie, List<ligne_panier_commande> ligne_panier,
			List<statistiquedebesoin> statbesoin) {
		super();
		this.idProduit = idProduit;
		this.image = image;
		this.referance = referance;
		this.nomProduit = nomProduit;
		this.prixProduit = prixProduit;
		this.dateCreation = dateCreation;
		this.categorie = categorie;
		this.ligne_panier = ligne_panier;
		this.statbesoin = statbesoin;
	}


	public Long getIdProduit() {
		return idProduit;
	}
	public void setIdProduit(Long idProduit) {
		this.idProduit = idProduit;
	}
	public String getNomProduit() {
		return nomProduit;
	}
	public void setNomProduit(String nomProduit) {
		this.nomProduit = nomProduit;
	}
	public Double getPrixProduit() {
		return prixProduit;
	}
	public void setPrixProduit(Double prixProduit) {
		this.prixProduit = prixProduit;
	}
	public Date getDateCreation() {
		return dateCreation;
	}
	public void setDateCreation(Date dateCreation) {
		this.dateCreation = dateCreation;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}

	public Categorie getCategorie() {
		return categorie;
	}

	public void setCategorie(Categorie categorie) {
		this.categorie = categorie;
	}
	

	public String getReferance() {
		return referance;
	}

	public void setReferance(String referance) {
		this.referance = referance;
	}

	@Override
	public String toString() {
		return "Produit [idProduit=" + idProduit + ", image=" + image + ", referance=" + referance + ", nomProduit="
				+ nomProduit + ", prixProduit=" + prixProduit + ", dateCreation=" + dateCreation + ", categorie="
				+ categorie + ", ligne_panier=" + ligne_panier + ", statbesoin=" + statbesoin + "]";
	}

	


	

}
