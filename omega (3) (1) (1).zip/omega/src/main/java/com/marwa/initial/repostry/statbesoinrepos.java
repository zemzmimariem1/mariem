package com.marwa.initial.repostry;

import org.springframework.data.jpa.repository.JpaRepository;

import com.marwa.initial.entity.statistiquedebesoin;

public interface statbesoinrepos  extends JpaRepository<statistiquedebesoin,Long> {
	statistiquedebesoin findByProduitIdProduit (Long id);
}
