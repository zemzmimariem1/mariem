package com.marwa.initial.restcontrollers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.marwa.initial.entity.Role;
import com.marwa.initial.service.roleservice;

@RestController
@RequestMapping("/apir")
@CrossOrigin
public class roleresetcontroller {
	@Autowired
	roleservice rolService;
	/*affiche tout les role*/
	@RequestMapping(method = RequestMethod.GET)
	public List<Role> getAllrole() {
	return rolService.getAllrole();
	}
	/*affiche les role par son id*/
	@RequestMapping(value="/{id}",method = RequestMethod.GET)
	public Role getroleById(@PathVariable("id") Long id) {
	return rolService.getrole(id);
	 }

}
