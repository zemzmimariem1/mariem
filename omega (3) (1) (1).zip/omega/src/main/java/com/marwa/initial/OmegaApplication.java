package com.marwa.initial;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OmegaApplication {

	public static void main(String[] args) {
		SpringApplication.run(OmegaApplication.class, args);
	}

}
