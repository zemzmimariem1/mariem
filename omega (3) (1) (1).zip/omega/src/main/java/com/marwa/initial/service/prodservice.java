package com.marwa.initial.service;

import java.util.List;

import com.marwa.initial.entity.Produit;
import com.marwa.initial.entity.commande;
import com.marwa.initial.entity.ligne_panier_commande;


public interface prodservice {
	Produit saveProduit(Produit p);
	Produit updateProduit(Produit p);
	void deleteProduit(Produit p);
	void deleteProduitById(Long id);
	Produit getProduit(Long id);
	List<Produit> getAllProduits();
	List<Produit> findByCategorieIdCat(Long id);
	List<Produit> getprodbynom(String nom);
	ligne_panier_commande ajoutaupanier(ligne_panier_commande cmd);
	List<commande> getAllcommande();
	void deleteProduitpanierbyid(long id);
}
