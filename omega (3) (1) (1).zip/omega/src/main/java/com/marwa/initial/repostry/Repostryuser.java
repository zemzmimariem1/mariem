package com.marwa.initial.repostry;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.marwa.initial.entity.User;


public interface Repostryuser extends JpaRepository<User, Long> {
	User findByemail(String email);
	List<User> findBynomContains(String nom);
	User findByPanierIdpanier ( Long id);
	List<User> findByRoleIdrole(Long id);
}
