package com.marwa.initial.service;



import java.util.Date;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.marwa.initial.entity.Panier;
import com.marwa.initial.entity.User;
import com.marwa.initial.entity.commande;
import com.marwa.initial.entity.ligne_panier_commande;
import com.marwa.initial.entity.statistiquedebesoin;
import com.marwa.initial.repostry.Repostrypanier;
import com.marwa.initial.repostry.Repostryuser;
import com.marwa.initial.repostry.commanderepostry;
import com.marwa.initial.repostry.repostrylignecommande;
import com.marwa.initial.repostry.statbesoinrepos;

@Service
public class panierserviceimp implements panierservice {
	@Autowired
	Repostrypanier panierRepository;
	@Autowired
	repostrylignecommande lignerepostry;
	@Autowired
	Repostryuser userrepostry;
	@Autowired
	commanderepostry comrepostry;
	@Autowired
	statbesoinrepos statbesrp;
	@Override
	public Panier savepanier(Panier p) {
		
		return panierRepository.save(p);
	}
	@Override
	public Panier getpannier(long id) {
		return  panierRepository.findById(id).get();
	}

	@Override
	public commande valider_panier(Panier pan) {
		List<ligne_panier_commande>p=lignerepostry.findByLpanierIdpanier(pan.getIdpanier());
		User u = userrepostry.findByPanierIdpanier(pan.getIdpanier());
		commande cmd = new commande();
		cmd.setId_client(u.getUser_id());
		cmd.setEtat("invalide");
		Double x=0.0;
		statistiquedebesoin stat;
		 for(int i = 0; i<p.size();i++) {
		  x =x+(p.get(i).getId_produit().getPrixProduit()*p.get(i).getQte());
		  stat = statbesrp.findByProduitIdProduit(p.get(i).getId_produit().getIdProduit());
		  int y =stat.getNbdemande()+1;
		  stat.setNbdemande(y);
		  /*stat.setIdproduit(stat.getIdproduit());*/
		 }
		 cmd.setTotal_prix(x);
		cmd.setDate(new Date());
		 return comrepostry.save(cmd);}

	@Override
	public void deletePanierById(Long id) {
		panierRepository.deleteById(id);
		
	}

	@Override
	public List<ligne_panier_commande> getlignepanier(Long id) {
		return lignerepostry.findByLpanierIdpanier(id);
	}

	
	

}
