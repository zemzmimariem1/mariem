package com.marwa.initial.restcontrollers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.marwa.initial.entity.Panier;
import com.marwa.initial.entity.commande;
import com.marwa.initial.entity.ligne_panier_commande;
import com.marwa.initial.repostry.repostrylignecommande;
import com.marwa.initial.service.panierservice;


@RestController
@RequestMapping("/app")
@CrossOrigin
public class panierresetcontroller {
	@Autowired
	panierservice panier;
	@Autowired
	repostrylignecommande lpanier;
	/*affiche panier par son id*/
	@RequestMapping(value ="/{id}",method = RequestMethod.GET)
	public Panier getpanierById(@PathVariable("id") Long id) {
	return panier.getpannier(id);
	 }
	/*créer un panier*/
	@RequestMapping(method = RequestMethod.POST)
	public Panier createProduit(@RequestBody Panier p) {
	return panier.savepanier(p);
	}
	/*valider panier et créer un commande*/
	@RequestMapping(value ="pan", method = RequestMethod.POST)
	public commande validepan(@RequestBody Panier p) {
	return panier.valider_panier(p);
	}
	/*affiche tout les ligne panier*/
	@RequestMapping(value ="pan",method = RequestMethod.GET)
	public List<ligne_panier_commande> getlignepanierById() {
	return lpanier.findAll();
	 }
	/*afficher les ligne panier lier par un panier identifier par  id*/
	@RequestMapping(value ="pan/{id}",method = RequestMethod.GET)
	public List<ligne_panier_commande> getlignepanierByIdpan (@PathVariable("id") Long id) {
	return lpanier.findByLpanierIdpanier(id);
	 }
	/*supprimer panier par id*/
	@RequestMapping(value="pan/{id}",method = RequestMethod.DELETE)
	public void deleteProduit(@PathVariable("id") Long id)
	{
		panier.deletePanierById(id);
	}

}
