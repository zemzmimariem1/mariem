package com.marwa.initial.restcontrollers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.marwa.initial.entity.statistiquedebesoin;
import com.marwa.initial.repostry.statbesoinrepos;

@RestController
@RequestMapping("/apistat")
@CrossOrigin
public class resetcontrollerstatistique {
	@Autowired
	statbesoinrepos statserv;
	/*afficher tout les statistique*/
	@RequestMapping(method = RequestMethod.GET)
	public List<statistiquedebesoin> getAllProduits() {
	return statserv.findAll();
	}
	/*affiche l'article par son id*/
	@RequestMapping(value="/{id}",method = RequestMethod.GET)
	public statistiquedebesoin getstatByIdprod(@PathVariable("id") Long id) {
	return statserv.findByProduitIdProduit(id);
	 }
	
}
