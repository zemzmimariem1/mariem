package com.marwa.initial.restcontrollers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.marwa.initial.entity.Reclamation;
import com.marwa.initial.entity.User;
import com.marwa.initial.entity.commande;
import com.marwa.initial.repostry.Repostryuser;
import com.marwa.initial.repostry.commanderepostry;
import com.marwa.initial.repostry.reclamationrepostry;
import com.marwa.initial.service.userservice;



@RestController
@CrossOrigin(origins = "*")
public class restcontrolleruser {
	/*methode de authentification*/
	@Autowired
	Repostryuser userRep;
	@RequestMapping(value ="/login/{email}",method = RequestMethod.GET)
	public User getUserByUsernamePassword(@PathVariable("email") String
			email) {
	return userRep.findByemail(email);
	}
	/*crud*/
	@Autowired
	userservice userService;
	@Autowired
	commanderepostry commrep;
	@Autowired
	reclamationrepostry recrepost;
	/*afficher tout les utilisateur*/
	@RequestMapping(value ="/apiu",method = RequestMethod.GET)
	public List<User> getAllUser() {
	return userService.getAllUser();
	}
	/*afficher user par son id*/
	@RequestMapping(value ="/apiu/{id}",method = RequestMethod.GET)
	public User getUserById(@PathVariable("id") Long id) {
	return userService.getUser(id);
	 }
	/*Enregistrer user */
	@RequestMapping(value ="/apiu",method = RequestMethod.POST)
	public User createUser(@RequestBody User u) {
		
		return userService.saveUser(u);
	}
	/*supprimer user par id*/
	@RequestMapping(value ="/apiu/{id}",method = RequestMethod.DELETE)
	public void deleteUser(@PathVariable("id") Long id)
	{
	    userService.deleteUserById(id);
	}
	/*update user*/
	@RequestMapping(value ="/apiu",method = RequestMethod.PUT)
	public User updateuser(@RequestBody User u) {
	return userService.updateUser(u);
	}
	/*affiche user par nom*/
	@RequestMapping(value ="/apiun/{nom}",method = RequestMethod.GET)
	public List<User> getUserBynom(@PathVariable("nom") String nom) {
	return userService.getbynom(nom);
	 }
	/*affiche user by id panier*/
	@RequestMapping(value="pan/{id}",method = RequestMethod.GET)
	public User getProduitByIdcat(@PathVariable("id") Long id) {
	return userRep.findByPanierIdpanier(id);
	 }
	/*affiche user by role*/
	@RequestMapping(value ="/api/role/{id}",method = RequestMethod.GET)
	public List<User> getAllUserbyroleid(@PathVariable("id") Long id) {
	return userService.getbyrole(id);
	}
	/*affiche les commande d'un client*/
	@RequestMapping(value ="/api/com/{id}",method = RequestMethod.GET)
	public List<commande> getAllcommandbyiduser(@PathVariable("id") Long id) {
	return commrep.findByIdclient(id);
	}
	/*affiche les commande by id*/
	@RequestMapping(value ="/api/comid/{id}",method = RequestMethod.GET)
	public commande getcommandbyid(@PathVariable("id") Long id) {
	return commrep.findById(id).get();
	}
	
	/*affiche les reclamation by id*/
	@RequestMapping(value ="/api/rec/{id}",method = RequestMethod.GET)
	public Reclamation getreclamationbyid(@PathVariable("id") Long id) {
	return recrepost.findById(id).get();
	}
}
