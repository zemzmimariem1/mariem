package com.marwa.initial.entity;




import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import com.fasterxml.jackson.annotation.JsonIgnore;
@Entity
public class Role {
	@Id
	@GeneratedValue (strategy=GenerationType.IDENTITY)
	private Long idrole;

	private String nom_role;
	@OneToMany (mappedBy = "role", cascade=CascadeType.ALL )
	@JsonIgnore
	private List<User> users;

	public Long getRole_id() {
		return idrole;
	}
	public void setRole_id(Long role_id) {
		this.idrole = role_id;
	}
	public String getRole() {
		return nom_role;
	}
	public void setRole(String role) {
		this.nom_role = role;
	}
	public List<User> getUsers() {
		return users;
	}
	public void setUsers(List<User> users) {
		this.users = users;
	}
}
