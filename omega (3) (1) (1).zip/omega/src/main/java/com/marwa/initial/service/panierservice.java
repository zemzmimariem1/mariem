package com.marwa.initial.service;



import java.util.List;

import com.marwa.initial.entity.Panier;
import com.marwa.initial.entity.commande;
import com.marwa.initial.entity.ligne_panier_commande;


public interface panierservice {
			Panier savepanier(Panier p);
			Panier getpannier(long id);
			commande valider_panier(Panier p);
			void deletePanierById(Long id);
			List<ligne_panier_commande> getlignepanier(Long id);
			
}
