package com.marwa.initial.service;

import java.util.List;

import com.marwa.initial.entity.Categorie;

public interface categorieservice {
	Categorie getcategori(Long id);
	List<Categorie> getAllcat();
}
