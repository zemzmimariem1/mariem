package com.marwa.initial.service;


import java.util.List;


import com.marwa.initial.entity.Role;

public interface roleservice {
	Role getrole(Long id);
	List<Role> getAllrole();
}
