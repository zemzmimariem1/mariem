package com.marwa.initial.repostry;

import org.springframework.data.jpa.repository.JpaRepository;

import com.marwa.initial.entity.Categorie;



public interface Repostrycategorie extends JpaRepository<Categorie, Long>{

}
