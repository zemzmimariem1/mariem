package com.marwa.initial.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Reclamation {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long idreclamation;
	private String msgrecu;
	private String msgreponse;
	private Date Daterecu;
	private Date Datereponse;
	@ManyToOne
	private commande cmd;
	public Long getIdreclamation() {
		return idreclamation;
	}
	public void setIdreclamation(Long idreclamation) {
		this.idreclamation = idreclamation;
	}
	public String getMsgrecu() {
		return msgrecu;
	}
	public void setMsgrecu(String msgrecu) {
		this.msgrecu = msgrecu;
	}
	public String getMsgreponse() {
		return msgreponse;
	}
	public void setMsgreponse(String msgreponse) {
		this.msgreponse = msgreponse;
	}
	public Date getDaterecu() {
		return Daterecu;
	}
	public void setDaterecu(Date daterecu) {
		Daterecu = daterecu;
	}
	public Date getDatereponse() {
		return Datereponse;
	}
	public void setDatereponse(Date datereponse) {
		Datereponse = datereponse;
	}
	public commande getCmd() {
		return cmd;
	}
	public void setCmd(commande cmd) {
		this.cmd = cmd;
	}
	@Override
	public String toString() {
		return "Reclamation [idreclamation=" + idreclamation + ", msgrecu=" + msgrecu + ", msgreponse=" + msgreponse
				+ ", Daterecu=" + Daterecu + ", Datereponse=" + Datereponse + ", cmd=" + cmd + "]";
	}
	public Reclamation(Long idreclamation, String msgrecu, String msgreponse, Date daterecu, Date datereponse,
			commande cmd) {
		super();
		this.idreclamation = idreclamation;
		this.msgrecu = msgrecu;
		this.msgreponse = msgreponse;
		Daterecu = daterecu;
		Datereponse = datereponse;
		this.cmd = cmd;
	}
	public Reclamation() {
		super();
		
	}
}
