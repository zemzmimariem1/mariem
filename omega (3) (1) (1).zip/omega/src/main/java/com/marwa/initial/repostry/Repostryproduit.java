package com.marwa.initial.repostry;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.marwa.initial.entity.Produit;



public interface Repostryproduit extends JpaRepository<Produit, Long> {
	List<Produit> findByNomProduit(String nom);
	 List<Produit> findByNomProduitContains(String nom); 
	 List<Produit> findByCategorieIdCat(Long id);
	 Produit findByReferance(String ref);
}
