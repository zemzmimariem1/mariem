package com.marwa.initial.service;

import java.util.List;


import com.marwa.initial.entity.User;

public interface userservice {
			User saveUser (User u);
			User updateUser(User u);
			void deleteUser(User u);
			void deleteUserById(Long id);
			User getUser(Long id);
			List<User> getAllUser();
			List<User>getbynom(String nom);
			List<User>getbyrole(Long id);
}
