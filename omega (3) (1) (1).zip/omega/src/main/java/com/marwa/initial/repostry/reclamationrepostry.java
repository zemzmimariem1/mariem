package com.marwa.initial.repostry;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.marwa.initial.entity.Reclamation;
import com.marwa.initial.entity.ligne_panier_commande;

public interface reclamationrepostry extends JpaRepository<Reclamation, Long> {
	Reclamation findByCmdIdcommande(Long id);
}
