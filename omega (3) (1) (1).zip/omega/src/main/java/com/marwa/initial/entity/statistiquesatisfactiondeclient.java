package com.marwa.initial.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity 
public class statistiquesatisfactiondeclient {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id ;
	private int ans;
	private int mois;
	private int nbdereclamation;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getAns() {
		return ans;
	}
	public void setAns(int ans) {
		this.ans = ans;
	}
	public int getMois() {
		return mois;
	}
	public void setMois(int mois) {
		this.mois = mois;
	}
	public int getNbdereclamation() {
		return nbdereclamation;
	}
	public void setNbdereclamation(int nbdereclamation) {
		this.nbdereclamation = nbdereclamation;
	}
	public statistiquesatisfactiondeclient(int id, int ans, int mois, int nbdereclamation) {
		super();
		this.id = id;
		this.ans = ans;
		this.mois = mois;
		this.nbdereclamation = nbdereclamation;
	}
	public statistiquesatisfactiondeclient() {
		super();
		
	}
	@Override
	public String toString() {
		return "statistiquesatisfactiondeclient [id=" + id + ", ans=" + ans + ", mois=" + mois + ", nbdereclamation="
				+ nbdereclamation + "]";
	}
	
}
