package com.marwa.initial.restcontrollers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.marwa.initial.entity.Categorie;

import com.marwa.initial.service.categorieservice;


@RestController
@RequestMapping("/apic")
@CrossOrigin
public class categorierestcontroller {
	@Autowired
	categorieservice catService;
	/*affiche liste des categorie*/
	@RequestMapping(method = RequestMethod.GET)
	public List<Categorie> getAllProduits() {
	return catService.getAllcat();
	}
	/*affiche catégorie par id*/
	@RequestMapping(value="/{id}",method = RequestMethod.GET)
	public Categorie getProduitById(@PathVariable("id") Long id) {
	return catService.getcategori(id);
	 }

}
