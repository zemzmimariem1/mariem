package com.marwa.initial.repostry;

import org.springframework.data.jpa.repository.JpaRepository;

import com.marwa.initial.entity.Panier;

public interface Repostrypanier extends JpaRepository<Panier , Long> {

}
