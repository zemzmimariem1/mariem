package com.marwa.initial.repostry;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.marwa.initial.entity.commande;



public interface commanderepostry extends JpaRepository<commande, Long> {
	List<commande> findByIdclient(Long id);

}
