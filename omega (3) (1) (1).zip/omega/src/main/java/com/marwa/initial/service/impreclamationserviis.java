package com.marwa.initial.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.marwa.initial.entity.Reclamation;
import com.marwa.initial.repostry.reclamationrepostry;
@Service
public class impreclamationserviis implements Reclamationservice {
	@Autowired
	reclamationrepostry recrepos;
	@Override
	public Reclamation saverec(Reclamation R) {
		R.setDaterecu(new Date());
		return recrepos.save(R);
	}

	@Override
	public Reclamation updaterec(Reclamation R) {
		R.setDaterecu(new Date());
		   return recrepos.save(R);
	}

	@Override
	public List<Reclamation> getAllreclamation() {
		
		return recrepos.findAll();
	}

}
