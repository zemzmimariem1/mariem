package com.marwa.initial.restcontrollers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.marwa.initial.entity.Produit;
import com.marwa.initial.entity.commande;
import com.marwa.initial.entity.ligne_panier_commande;
import com.marwa.initial.repostry.Repostryproduit;
import com.marwa.initial.repostry.repostrylignecommande;
import com.marwa.initial.service.prodservice;





@RestController
@RequestMapping("/api")
@CrossOrigin

public class Produitrestcontroller {
	@Autowired
	prodservice prodService;
	@Autowired
	repostrylignecommande lr;
	@Autowired
	Repostryproduit repprod;
	/*afficher tout les article*/
	@RequestMapping(method = RequestMethod.GET)
	public List<Produit> getAllProduits() {
	return prodService.getAllProduits();
	}
	/*affiche l'article par son id*/
	@RequestMapping(value="/{id}",method = RequestMethod.GET)
	public Produit getProduitById(@PathVariable("id") Long id) {
	return prodService.getProduit(id);
	 }
	/*ajouter un article*/
	@RequestMapping(method = RequestMethod.POST)
	public Produit createProduit(@RequestBody Produit produit) {
	return prodService.saveProduit(produit);
	}
	/*supprimer article par son id*/
	@RequestMapping(value="/{id}",method = RequestMethod.DELETE)
	public void deleteProduit(@PathVariable("id") Long id)
	{
	prodService.deleteProduitById(id);
	}
/*modier les information d'un article*/
	@RequestMapping(method = RequestMethod.PUT)
	public Produit updateProduit(@RequestBody Produit produit) {
	return prodService.updateProduit(produit);
	}
	/*afficher un article par categorie*/
	@RequestMapping(value="cat/{id}",method = RequestMethod.GET)
	public List<Produit> getProduitByIdcat(@PathVariable("id") Long id) {
	return prodService.findByCategorieIdCat(id);
	 }
	/*afficher un article par nom*/
	@RequestMapping(value="nom/{nom}",method = RequestMethod.GET)
	public List<Produit> getProduitBynom(@PathVariable("nom") String nom) {
	return prodService.getprodbynom(nom);
	 }
	/*afficher un article par referance*/
	@RequestMapping(value="ref/{nom}",method = RequestMethod.GET)
	public Produit getProduitByref(@PathVariable("nom") String nom) {
	return repprod.findByReferance(nom);
	 }
	/*ajouter un article dans ligne panier*/
	@RequestMapping(value="ligne" ,method = RequestMethod.POST)
	public ligne_panier_commande createProduit(@RequestBody ligne_panier_commande cmd) {
		return prodService.ajoutaupanier(cmd);
	}
	/*affiche tout les ligne panier*/
	@RequestMapping(value="ligne",method = RequestMethod.GET)
	public List<ligne_panier_commande> getAllligne() {
	return lr.findAll();
	}
	/*affiche tout les commande*/
	@RequestMapping(value="comm",method = RequestMethod.GET)
	public List<commande> getpanier() {
	return prodService.getAllcommande();
	}
	/*supprimer article de panier*/
	@RequestMapping(value="comm/{id}",method = RequestMethod.DELETE)
	public void deleteProduitpanier(@PathVariable("id") Long id)
	{
	prodService.deleteProduitpanierbyid(id);
	}
}
