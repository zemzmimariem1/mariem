package com.marwa.initial.service;


import java.util.List;

import com.marwa.initial.entity.Reclamation;

public interface Reclamationservice {
	Reclamation saverec(Reclamation R);
	Reclamation updaterec(Reclamation R);
	List<Reclamation> getAllreclamation();
}
