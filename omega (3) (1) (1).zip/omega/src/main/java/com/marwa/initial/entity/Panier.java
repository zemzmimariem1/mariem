package com.marwa.initial.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import com.fasterxml.jackson.annotation.JsonIgnore;



@Entity
public class Panier {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long idpanier;
	
	@OneToMany(mappedBy = "panier", cascade=CascadeType.ALL)
	@JsonIgnore
	    private List<User> user;
	
	@OneToMany(mappedBy = "lpanier", cascade=CascadeType.ALL)
	@JsonIgnore
	    private List<ligne_panier_commande> lignepanier;

	public Long getIdpanier() {
		return idpanier;
	}

	public void setIdpanier(Long idpanier) {
		this.idpanier = idpanier;
	}
	
	  
}
