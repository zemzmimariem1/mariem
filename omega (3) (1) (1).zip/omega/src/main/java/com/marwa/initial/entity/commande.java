package com.marwa.initial.entity;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;


@Entity
public class commande {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long idcommande;
	@ManyToOne
	private ligne_panier_commande id_ligne_panier;
	private long idclient;
	private String etat;
	private Date date;
	private Double total_prix;
	@OneToMany (mappedBy = "cmd", cascade=CascadeType.ALL)
	@JsonIgnore
	private List<Reclamation>recmlamation;
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public Double getTotal_prix() {
		return total_prix;
	}
	public void setTotal_prix(Double total_prix) {
		this.total_prix = total_prix;
	}
	public ligne_panier_commande getId_ligne_panier() {
		return id_ligne_panier;
	}
	public void setId_ligne_panier(ligne_panier_commande id_ligne_panier) {
		this.id_ligne_panier = id_ligne_panier;
	}
	public String getEtat() {
		return etat;
	}
	public void setEtat(String etat) {
		this.etat = etat;
	}
	public Long getIdcommande() {
		return idcommande;
	}
	public void setIdcommande(Long idcommande) {
		this.idcommande = idcommande;
	}
	public ligne_panier_commande getId_panier() {
		return id_ligne_panier;
	}
	public void setId_panier(ligne_panier_commande id_ligne_panier) {
		this.id_ligne_panier = id_ligne_panier;
	}
	
	public long getId_client() {
		return idclient;
	}
	public void setId_client(long id_client) {
		this.idclient = id_client;
	}
	
	

	public commande(Long idcommande, ligne_panier_commande id_ligne_panier, long id_client, String etat, Date date,
			Double total_prix) {
		super();
		this.idcommande = idcommande;
		this.id_ligne_panier = id_ligne_panier;
		this.idclient = id_client;
		this.etat = etat;
		this.date = date;
		this.total_prix = total_prix;
	}
	public commande() {
		super();
		
	}
	@Override
	public String toString() {
		return "commande [idcommande=" + idcommande + ", id_ligne_panier=" + id_ligne_panier + ", id_client="
				+ idclient + ", etat=" + etat + ", date=" + date + ", total_prix=" + total_prix + "]";
	}
	
	

}

