package com.marwa.initial.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.marwa.initial.entity.Panier;
import com.marwa.initial.entity.User;
import com.marwa.initial.repostry.Repostrypanier;
import com.marwa.initial.repostry.Repostryuser;
@Service
public class userserviceimp implements userservice{
	@Autowired
	Repostryuser userRepository;
	@Autowired
	Repostrypanier panRepository;
	@Autowired
	panierservice panier;
	@Override
	public User saveUser(User u) {
	  if((u.getRole().getRole_id())==3){
		Panier p =  new Panier();
		panRepository.save(p);
		u.setPanier(p);}
		return userRepository.save(u);
	}

	@Override
	public User updateUser(User u) {
		
		return userRepository.save(u);
	}

	@Override
	public void deleteUser(User u) {
		userRepository.delete(u);
		
		}

	@Override
	public void deleteUserById(Long id) {
		User u =userRepository.findById(id).get();
		
		if((u.getRole().getRole_id())==3){
			userRepository.deleteById(id);
			panier.deletePanierById(u.getPanier().getIdpanier());}
		else
			userRepository.deleteById(id);
		
		
	}

	@Override
	public User getUser(Long id) {
		
		return userRepository.findById(id).get();
	}

	@Override
	public List<User> getAllUser() {
		
		return userRepository.findAll();
	}

	@Override
	public List<User> getbynom(String nom) {
		
		return userRepository.findBynomContains(nom);
	}
	@Override
	public List<User> getbyrole(Long id) {
		
		return userRepository.findByRoleIdrole(id);
	}
	

}
