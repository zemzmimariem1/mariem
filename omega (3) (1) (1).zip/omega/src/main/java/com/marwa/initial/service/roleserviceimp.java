package com.marwa.initial.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.marwa.initial.entity.Role;
import com.marwa.initial.repostry.Repostryrole;
@Service
public class roleserviceimp implements roleservice {
	@Autowired
Repostryrole reporol;
	@Override
	public Role getrole(Long id) {
		
		return reporol.findById(id).get();
	}
	@Override
	public List<Role> getAllrole() {
		
		return reporol.findAll();
	}

}
