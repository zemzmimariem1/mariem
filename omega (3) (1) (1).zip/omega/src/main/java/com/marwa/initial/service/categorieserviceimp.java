package com.marwa.initial.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.marwa.initial.entity.Categorie;
import com.marwa.initial.repostry.Repostrycategorie;
@Service
public class categorieserviceimp implements categorieservice {
	@Autowired
	Repostrycategorie repostrycat;
	@Override
	public Categorie getcategori(Long id) {
		
		return repostrycat.findById(id).get();
	}

	@Override
	public List<Categorie> getAllcat() {
		
		return repostrycat.findAll();
	}

}
