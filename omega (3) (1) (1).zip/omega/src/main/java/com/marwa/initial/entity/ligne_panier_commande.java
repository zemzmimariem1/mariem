package com.marwa.initial.entity;

import java.sql.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class ligne_panier_commande {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long idligne;
private Date date_commande;
private int qte;
@ManyToOne
private Panier lpanier;
@ManyToOne
private Produit id_produit;
@OneToMany(mappedBy = "id_ligne_panier", cascade=CascadeType.ALL)
@JsonIgnore
    private List<commande> comm;


public Long getIdligne() {
	return idligne;
}
public void setIdligne(Long idligne) {
	this.idligne = idligne;
}
public Date getDate_commande() {
	return date_commande;
}
public void setDate_commande(Date date_commande) {
	this.date_commande = date_commande;
}
public int getQte() {
	return qte;
}
public void setQte(int qte) {
	this.qte = qte;
}
public Panier getLpanier() {
	return lpanier;
}
public void setLpanier(Panier lpanier) {
	this.lpanier = lpanier;
}
public Produit getId_produit() {
	return id_produit;
}
public void setId_produit(Produit id_produit) {
	this.id_produit = id_produit;
}
public List<commande> getComm() {
	return comm;
}
public void setComm(List<commande> comm) {
	this.comm = comm;
}
public ligne_panier_commande(Long idligne,  int qte, Produit id_produit) {
	super();
	this.idligne = idligne;
	this.qte = qte;
	this.id_produit = id_produit;
}
public ligne_panier_commande(Long idligne, Date date_commande, int qte, Panier lid_panier, Produit id_produit,
		List<commande> comm) {
	super();
	this.idligne = idligne;
	this.date_commande = date_commande;
	this.qte = qte;
	this.lpanier = lid_panier;
	this.id_produit = id_produit;
	this.comm = comm;
}
public ligne_panier_commande() {
	super();
	}
@Override
public String toString() {
	return "ligne_panier_commande [idligne=" + idligne + ", date_commande=" + date_commande + ", qte=" + qte
			+ ", id_panier=" + lpanier + ", id_produit=" + id_produit + ", comm=" + comm + "]";
}


}
