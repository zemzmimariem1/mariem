package com.marwa.initial.entity;



import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class statistiquedebesoin {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private int ans;
	private int mois;
	private int nbdemande;
	@ManyToOne
	private Produit produit;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getAns() {
		return ans;
	}
	public void setAns(int ans) {
		this.ans = ans;
	}
	public int getMois() {
		return mois;
	}
	public void setMois(int mois) {
		this.mois = mois;
	}
	public int getNbdemande() {
		return nbdemande;
	}
	public void setNbdemande(int nbdemande) {
		this.nbdemande = nbdemande;
	}
	public Produit getIdproduit() {
		return produit;
	}
	public void setIdproduit(Produit idproduit) {
		this.produit = idproduit;
	}
	public statistiquedebesoin(int id, int ans, int mois, int nbdemande, Produit idproduit) {
		super();
		this.id = id;
		this.ans = ans;
		this.mois = mois;
		this.nbdemande = nbdemande;
		this.produit = idproduit;
	}
	public statistiquedebesoin() {
		super();
		
	}
	@Override
	public String toString() {
		return "statistiquedebesoin [id=" + id + ", ans=" + ans + ", mois=" + mois + ", nbdemande=" + nbdemande
				+ ", idproduit=" + produit + "]";
	}
	
}
